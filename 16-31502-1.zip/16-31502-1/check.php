<?php
	
	session_start();
	
	$name = $_POST['name'];
	$pass = $_POST['pass'];
	
	if($name == "hum" && $pass == "12"){
		$_SESSION["name"]= "hum";
		
		header("Location: home.php");
	}else{

		header("Location: login.php");
	}
?>