<fieldset>
    <legend><b>REGISTRATION</b></legend>
	<form  action=" " method="POST">
		<br/>
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><input name="name" type="text"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td>
					<input name="email" type="text">
					<abbr title="hint: sample@example.com"><b>i</b></abbr>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>User Name</td>
				<td>:</td>
				<td><input name="userName" type="text"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input name="password" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td>Confirm Password</td>
				<td>:</td>
				<td><input name="confirmPassword" type="password"></td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Gender</legend>    
						<input name="gender" type="radio">Male
						<input name="gender" type="radio">Female
						<input name="gender" type="radio">Other
					</fieldset>
				</td>
				<td></td>
			</tr>		
			<tr><td colspan="4"><hr/></td></tr>
			<tr>
				<td colspan="3">
					<fieldset>
						<legend>Date of Birth</legend>    
						<input type="text" size="2" />/
						<input type="text" size="2" />/
						<input type="text" size="4" />
						<font size="2"><i>(dd/mm/yyyy)</i></font>
					</fieldset>
				</td>
				<td></td>
			</tr>
		</table>
		<hr/>
		<input type="submit" value="Submit">
		<input type="reset">
	</form>

	<?php

				session_start();
				session_unset(); 

				$errorlist =array("nameErr" => "Name is required.<br/>", "nameFormatErr" => "Name should only Contain characterts.<br/>","emailErr" => "Email is required","emailformatErr" => "Invalid email format.<br/>","passwordErr" => "Password required.<br/>","confPasswordErr" => "Input the password again.<br/>","passwordMatchErr" => "Password doesn't match.<br/>","fullNameErr" => "Input Your Full name.<br/>","genErr" => "gender is required.<br/>");

				$success=0;
				if ($_SERVER["REQUEST_METHOD"] == "POST") 
				{

					  if (empty($_POST["username"])) 
					  {
					    echo $errorlist["nameErr"]; 
					  } 
					  else 
					  {
					  	if(!preg_match("/^[a-zA-Z ]*$/",$_POST["username"]))  
					  	{
							echo $errorlist["nameFormatErr"]; 
					  	}
					  	else
					  	{
					    	$_SESSION["username"] = dataFilter($_POST["username"]);
					    	$success++;
					  	}
					  }
           
		   
		              if (empty($_POST["email"])) 
					  {
					    echo $errorlist["emailErr"];
					  } 
					  else 
					  {
					  	if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) 
					  	{
						  echo $errorlist["emailformatErr"];
						}
						else
						{
							$_SESSION["email"] = dataFilter($_POST["email"]);
							$success++;
						}

					  }
 
                       if (empty($_POST["fullName"])) 
					  {
					    echo $errorlist["fullNameErr"]; 

					  } 
					  else 
					  {
					  	if(!preg_match("/^[a-zA-Z ]*$/",$_POST["fullName"]))  
					  	{
							echo $errorlist["nameFormatErr"]; 
					  	}
					  	else
					  	{
					    	$_SESSION["fullName"] = dataFilter($_POST["fullName"]);
					    	$success++;
					  	}
					  }
 
					  if (empty($_POST["password"])) 
					  {
					    echo $errorlist["passwordErr"]; 
					  } 
					  else
					  {
					    $_SESSION["password"] = dataFilter($_POST["password"]);
					    $success++;
					  }

					  if (empty($_POST["confirmPass"])) 
					  {
					    echo $errorlist["confPasswordErr"]; 
					  } 
					  else
					  {
					  	if($_POST["confirmPass"]===$_POST["password"])
					  	{
					  		$_SESSION["confirmPass"] = dataFilter($_POST["confirmPass"]);
					  		$success++;
					  	}

					  	else
					  	{
					  		echo $errorlist["passwordMatchErr"]; 
					  	}
					    
					  }
					  
					  print_r($_SESSION);

					  if($success==6)
					  {
					  	header("location:index.php");
					  }
					  else
					  	$success=0;
	  
				}

				function dataFilter($data)
				{
					$data = trim($data);
					$data = stripcslashes($data);
					$data = htmlspecialchars($data);

					return $data;
				}

			?>

	
	
	
	
</fieldset>

